# Ansar Zaman Portfolio Website

## Publish with GitHub Pages
1. Create a GitHub repository named `YOURUSERNAME.github.io` (replace YOURUSERNAME with your GitHub username).
2. Upload `index.html` and `banner.jpg` to the repository root.
3. Open Settings → Pages.
4. Choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Your portfolio will publish at `https://YOURUSERNAME.github.io/` after the deployment completes.
